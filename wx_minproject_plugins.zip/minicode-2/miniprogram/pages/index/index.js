var plugin = requirePlugin("hello-plugin");
Page({
  data: {
    items: [],
    currentItem: 0,
    word: ''
  },
  onLoad: function () {
    plugin.sayHello();
    wx.getLocation({
      success: function(res) {
        console.log('获取地理位置信息', res)
      },
    })
    this.setData({ word: plugin.answer})
    // var world = plugin.answer;
  },
  addItem: function () {
    this.data.items.push(this.data.currentItem++);
    this.setData({
      items: this.data.items,
      currentItem: this.data.currentItem
    });
    wx.openLocation({
      latitude: 22.52291,
      longitude: 114.05454
    })
  }
});