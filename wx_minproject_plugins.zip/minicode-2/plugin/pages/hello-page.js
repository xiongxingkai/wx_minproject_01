// plugin/pages/hello-page.js
Page({
  data: {
    name: 'xxk',
    age: 30
  },
  onLoad: function () {
    console.log('This is a plugin page!');
    wx.getNetworkType({
      success: function(res) {
        console.log('获取网络信息', res)
      },
    })
  },
  getSystemInfo() {
    wx.getSystemInfo({
      success: function(res) {
        console.log('获取系统信息', res)
      },
    })
  }
});