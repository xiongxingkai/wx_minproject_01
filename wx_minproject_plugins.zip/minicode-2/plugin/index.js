module.exports = {
  sayHello: function () {
    console.log('Hello plugin!')
  },
  answer: 58
}