const app = getApp()

Page({
  data: {
    started: false,
    title: '计时器'
  },
  start: function() {
    this.setData({
      started: true
    })
    console.log('主页面数据：', this.data, this.title)
    this.selectComponent('#stopwatch').start()
  },
  stop: function() {
    this.setData({
      started: false
    })
    this.selectComponent('#stopwatch').stop()
  }
})
